package stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementerLocator.ElementLocator;

public class StepDefinition {
	
	@Given("^Conference registration page$")
	public void conference_registration_page() throws Throwable {
	  pageFactPack.PageFactory.openbrowser("C:\\Users\\sojeyaku\\Desktop\\New folder\\conferenceregistration_187039\\target\\ConferenceRegistartion.html");
	}

	@When("^User come to registration page$")
	public void user_come_to_registration_page() throws Throwable {
	   pageFactPack.PageFactory.verifyTitle();     //verify the title 
	}

	@When("^validate firstname$")
	public void validate_firstname() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.firstName, "xxx");
	   
	}

	@When("^validate lastname$")
	public void validate_lastname() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.lastName,"yyy");
	   
	}

	@When("^validate email$")
	public void validate_email() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.email,"xxx@gmail.com");
	   
	}

	@When("^validate contactNo$")
	public void validate_contactNo() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.contact,"7890657890");
	   
	}

	@When("^select no\\.of\\.attending$")
	public void select_no_of_attending() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
	//	Thread.sleep(3000);
		pageFactPack.PageFactory.select(ElementLocator.noOfAttending,"2");
	}

	@When("^validate roomNo$")
	public void validate_roomNo() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.roomNo,"567");
	}

	@When("^validate areaname$")
	public void validate_areaname() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.area,"zzz street"); 
	}

	@When("^select city$")
	public void select_city() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.select(ElementLocator.city,"Chennai");	    
	}

	@When("^select state$")
	public void select_state() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
		Thread.sleep(3000);
		pageFactPack.PageFactory.select(ElementLocator.state,"Tamilnadu");
	}

	@When("^select membership satus$")
	public void select_membership_satus() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
		pageFactPack.PageFactory.alertHandler();
	//	Thread.sleep(3000);
		pageFactPack.PageFactory.clickmethod(ElementLocator.membershipStatus);
	}

	@Then("^click on next$")
	public void click_on_next() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.nextLink);
	}

	@Given("^Payment details page$")
	public void payment_details_page() throws Throwable {
		
	    
	}

	@When("^User come to payment details page$")
	public void user_come_to_payment_details_page() throws Throwable {
		pageFactPack.PageFactory.alertHandler(); 
	}

	@When("^validate cardholdername$")
	public void validate_cardholdername() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.submit);
		pageFactPack.PageFactory.alertHandler();
		//Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.cardHolderName,"asdf");
	}

	@When("^validate debitcardnumber$")
	public void validate_debitcardnumber() throws Throwable {
	pageFactPack.PageFactory.clickmethod(ElementLocator.submit);
		pageFactPack.PageFactory.alertHandler();
//		Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.dbNumber,"8907654321");
	}

	@When("^validate cvv$")
	public void validate_cvv() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.submit);
	pageFactPack.PageFactory.alertHandler();
//		Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.cvv,"456");
	}

	@When("^validate expiration month$")
	public void validate_expiration_month() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.submit);
		pageFactPack.PageFactory.alertHandler();
		Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.exMonth,"12");
	}

	@When("^validate expiration year$")
	public void validate_expiration_year() throws Throwable {
		pageFactPack.PageFactory.clickmethod(ElementLocator.submit);
		pageFactPack.PageFactory.alertHandler();
	Thread.sleep(3000);
		pageFactPack.PageFactory.sendvalue(ElementLocator.exYear,"2050");
	}

	@Then("^click on make payment$")
	public void click_on_make_payment() throws Throwable {
	  //  pageFactPack.PageFactory.clickmethod(ElementLocator.submit);
	}

	@Then("^close the browser window$")
	public void close_the_browser_window() throws Throwable {
		
	    pageFactPack.PageFactory.close();
	}


}
