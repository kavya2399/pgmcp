package elementerLocator;

import org.openqa.selenium.By;

public class ElementLocator {
	public static By cTitle=By.xpath("/html/head/title");
	public static By firstName=By.id("txtFirstName");
	public static By lastName=By.name("txtLN");
	public static By email=By.id("txtEmail");
	public static By contact=By.id("txtPhone");
	public static By noOfAttending=By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select");
	public static By roomNo=By.id("txtAddress1");
	public static By area=By.id("txtAddress2");
	public static By city=By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select");
	public static By state=By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select");
	public static By membershipStatus=By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input");
	public static By nextLink=By.xpath("/html/body/form/table/tbody/tr[14]/td/a");
	public static By cardHolderName=By.id("txtCardholderName");
	public static By dbNumber=By.name("debit");
	public static By cvv=By.name("cvv");
	public static By exMonth=By.id("txtMonth");
	public static By exYear=By.id("txtYear");
	public static By submit=By.xpath("//*[@id=\"btnPayment\"]");
	public static By title=By.xpath("/html/head/title");
}